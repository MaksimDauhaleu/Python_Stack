Here you can find a simple template of e-commerce Sneaker Shop site written with Python Django
