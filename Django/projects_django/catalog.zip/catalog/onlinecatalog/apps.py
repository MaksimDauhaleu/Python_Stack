from django.apps import AppConfig


class OnlinecatalogConfig(AppConfig):
    name = 'onlinecatalog'
