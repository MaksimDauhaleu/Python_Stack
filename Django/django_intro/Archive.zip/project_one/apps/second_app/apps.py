from django.apps import AppConfig


class SecondAppConfig(AppConfig):
    name = 'second_app'
