from django.apps import AppConfig


class YourAppNameHereConfig(AppConfig):
    name = 'your_app_name_here'
